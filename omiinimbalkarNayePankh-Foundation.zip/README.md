# NayePankh Foundation Website
**Front End Development Internship — Option 2**

A fully responsive, multi-section static website for NayePankh Foundation built with pure HTML, CSS, and vanilla JavaScript.

---

## 📁 Folder structure

```
nayepankh-foundation/
├── index.html          ← Main webpage (all sections)
├── css/
│   └── style.css       ← All styles, CSS variables, responsive rules
├── js/
│   └── main.js         ← Dark mode, scroll animations, counter, nav
├── images/             ← Drop images here (hero photo, etc.)
└── README.md           ← This file
```

---

## ✅ Features implemented

### Sections
1. **Navbar** — sticky on scroll, active link highlighting
2. **Hero** — headline, stats, floating info cards
3. **About** — mission, values, visual card grid
4. **Programs** — 6 program cards (Shiksha, Poshan, Kaushal, Mann, Shakti, Hariyali)
5. **Impact** — animated counter numbers, full-width dark band
6. **Get Involved** — Volunteer / Donate / Partner cards
7. **Testimonials** — 3 real-style quotes from beneficiaries and volunteers
8. **Newsletter CTA** — email subscribe form
9. **Footer** — brand, 3 link columns, social icons, legal note

### Extras
- 🌙 **Dark mode** — toggle button in navbar; respects `prefers-color-scheme`; saves to `localStorage`
- 📱 **Responsive design** — mobile-first breakpoints at 640px and 900px; hamburger menu on mobile
- ✨ **Scroll animations** — `IntersectionObserver`-based fade-in + stagger for card grids
- 🔢 **Animated counters** — numbers count up when they scroll into view
- 🎯 **Floating cards** — hero section floating badges with CSS keyframe animation
- ♿ **Accessibility** — ARIA labels, roles, skip links, `prefers-reduced-motion` respected

---

## 🎨 Design decisions

| Token | Choice | Reason |
|---|---|---|
| Primary color | Deep forest green `#1a4530` | Nature, growth, hope — aligned with NayePankh's mission |
| Accent | Saffron `#f7941d` | Warmth, India, energy — complementary contrast |
| Background | Warm cream `#fdf8f2` | Friendly, not clinical; easier on eyes |
| Font | Inter | Clean, modern, excellent readability at all sizes |
| Signature element | Floating animated cards in hero | Brings life to the hero without using real photos |

---

## 🚀 How to run

Just open `index.html` in any browser — no build tools, no dependencies, no server required.

```bash
# Mac / Linux
open index.html

# Or drag and drop into Chrome / Firefox / Edge
```

---

## 💡 Suggested next steps

- Replace the hero placeholder with a real photo in `images/`
- Connect the donate button to Razorpay / PayU
- Add a live volunteer application form
- Integrate with a CMS (e.g. Contentful) for program updates

---

*Built as part of the NayePankh Foundation Front End Development Internship.*
